using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TwinkleToDoAPI.Data;

[Route("api/[controller]")]
[ApiController]
public class UserSettingsController : ControllerBase
{
    private readonly AppDbContext _context;

    public UserSettingsController(AppDbContext context)
    {
        _context = context;
    }

    // ✅ Get user settings by User ID
    [HttpGet("{userId}")]
    public async Task<ActionResult<UserSettings>> GetUserSettings(int userId)
    {
        var settings = await _context.UserSettings.FindAsync(userId);

        if (settings == null)
            return NotFound();

        return settings;
    }

    // ✅ Update user settings
    [HttpPut("{userId}")]
    public async Task<IActionResult> UpdateUserSettings(int userId, UserSettings settings)
    {
        if (userId != settings.UserId)
            return BadRequest();

        _context.Entry(settings).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_context.UserSettings.Any(e => e.UserId == userId))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }
}
