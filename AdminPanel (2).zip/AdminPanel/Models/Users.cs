using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

public class User
{
    [Key]
    public int UserId { get; set; }

    
    public string Username { get; set; } = string.Empty;

    
    public string Email { get; set; } = string.Empty;

    
    public string Password { get; set; } = string.Empty;

    // Navigation properties
    public ICollection<TaskItem>? Tasks { get; set; }
    public UserSettings? UserSettings { get; set; }
}
