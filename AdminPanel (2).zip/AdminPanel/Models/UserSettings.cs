using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class UserSettings
{
    [Key]
    [ForeignKey("User")]
    public int UserId { get; set; }

    [Required]
    [MaxLength(20)]
    public string Theme { get; set; } = "system";

    public bool NotificationsEnabled { get; set; } = true;

    // Navigation property
    public User? User { get; set; }
}
