using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly AppDbContext _context;
    public AdminController(AppDbContext context) { _context = context; }
    public IActionResult Index() { return View(_context.Users.ToList()); }
    public IActionResult Tasks() { return View(_context.Tasks.ToList()); }
}