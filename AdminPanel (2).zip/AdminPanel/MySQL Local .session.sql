INSERT INTO users (username, email, password) VALUES
('JaneDavid', 'jane@gmail.com', '1234'),
('PatriciaS', 'pesh@gmail.com', '5678');
